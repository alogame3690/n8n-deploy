#!/bin/bash

# Dừng nếu có lỗi
set -e

# Tạo thư mục data nếu chưa có
mkdir -p ./n8n_data

# Cấp quyền thực thi cho script
chmod +x deploy.sh

# Khởi động hệ thống
docker compose up -d
